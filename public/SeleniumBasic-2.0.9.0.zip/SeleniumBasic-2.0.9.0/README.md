# SeleniumBasic
A Selenium based browser automation framework for VB.Net, Visual Basic Applications and VBScript
