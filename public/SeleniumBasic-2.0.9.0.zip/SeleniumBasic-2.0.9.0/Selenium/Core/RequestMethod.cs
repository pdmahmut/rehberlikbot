﻿using System;

namespace Selenium.Core {

    enum RequestMethod {
        POST, 
        GET, 
        DELETE
    };

}
