﻿
namespace vbsc {

    struct WithParams {
        public string Params;
        public int Line;
    }

}
